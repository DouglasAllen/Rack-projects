s = "Hello " << "world"
puts( s )
s = "Hello " + "world"
puts( s )
s = "Hello "  "world"
puts( s )
