# The Book of Ruby - http://www.sapphiresteel.com

s = "Hello world"
puts( "s=#'{s}'" )
puts( "s[0]=#{s[0]}, s[0,1]='#{s[0,1]}', s[-1]=#{s[-1]}, s[-1,1]='#{s[-1,1]}'" )
puts( "s[0,5]='#{s[0,5]}' and s[-5,5]='#{s[-5,5]}'" )
puts( "s[0..5]='#{s[0..5]}' and s[-5..-1]='#{s[-5..-1]}'" )