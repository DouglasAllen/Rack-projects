# The Book of Ruby - http://www.sapphiresteel.com

module MyMod
end

puts( MyMod.class )

# This is not allowed!
# module MyOtherMod < MyMod
# end
