# The Book of Ruby - http://www.sapphiresteel.com

require( "./testmod.rb" )
# require_relative( "testmod.rb" ) # Ruby 1.9 only


# If the currrent directoruy (.) is not stored in $: you can add it
# Then you can use an unqualified path name
# Uncomment the following to try this...
# $: << "."
# require( "testmod.rb" )
