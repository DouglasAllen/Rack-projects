# The Book of Ruby - http://www.sapphiresteel.com

puts( "Three requires..." )
require "./test"
require "./test"
require "./test"