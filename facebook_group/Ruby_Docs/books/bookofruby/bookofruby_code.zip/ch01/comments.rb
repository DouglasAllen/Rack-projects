# this is a comment

puts( "hello" ) # this is also a comment

=begin
 This is a 
 multiline
 comment
=end

puts( "goodbye" )