# The Book of Ruby - http://www.sapphiresteel.com

puts( :hello.object_id )
puts( :hello.object_id )
puts( :hello.object_id )
puts
puts( "hello".object_id )
puts( "hello".object_id )
puts( "hello".object_id )