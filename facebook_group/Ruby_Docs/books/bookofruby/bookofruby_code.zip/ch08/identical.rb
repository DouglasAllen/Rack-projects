# The Book of Ruby - http://www.sapphiresteel.com

s1 = "hello"
s2 = "hello"

f1 = 10.00
f2 = 10.00

i1 = 10
i2 = 10

puts( "s1.equal?(s2) #{s1.equal?(s2)}" )
puts( "f1.equal?(f2) #{f1.equal?(f2)}" )
puts( "i1.equal?(i2) #{i1.equal?(i2)}" )
puts( "10.0.equal?(10.0) #{10.0.equal?(10.0)}" )
puts( "10.equal?(10) #{10.equal?(10)}" )
