# The Book of Ruby - http://www.sapphiresteel.com

def method1
	a = 1
	b = 2
	c = a + b
end

def method2
	a = 1
	b = 2
	c = a + b
	return b
end

def method3
	"hello"
end

def method4
	a = 1 + 2
	"goodbye"
end

def method5
end

p( method1 )
p( method2 )
p( method3 )
p( method4 )
p( method5 )

