puts Math::PI
Math::PI = 100
puts Math::PI