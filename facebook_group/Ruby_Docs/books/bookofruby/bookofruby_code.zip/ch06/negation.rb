# The Book of Ruby - http://www.sapphiresteel.com

puts ( !(1==1))
puts ( (1!=1))
puts ( not(1==1))
