# The Book of Ruby - http://www.sapphiresteel.com

name = "Fred"
puts( name.send( :reverse ) )
puts( name.send( :upcase ) )
