# The Book of Ruby - http://www.sapphiresteel.com

def method_missing( methodname ) 
	puts( "Sorry, #{methodname} does not exist" )
end	

xxx