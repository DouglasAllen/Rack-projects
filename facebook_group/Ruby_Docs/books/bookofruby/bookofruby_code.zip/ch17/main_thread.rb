# The Book of Ruby - http://www.sapphiresteel.com

puts( Thread.main.priority )
Thread.main.priority=100
puts( Thread.main.priority )