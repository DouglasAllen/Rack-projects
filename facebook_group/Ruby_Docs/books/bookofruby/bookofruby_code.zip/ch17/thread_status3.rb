t =  Thread.new{  }
p t
p t.kill
 sleep( 1 )
puts( t.inspect )		