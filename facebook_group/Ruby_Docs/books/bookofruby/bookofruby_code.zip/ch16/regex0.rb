# The Book of Ruby - http://www.sapphiresteel.com

p( /abc/ =~ 'abc' )
p( /abc/ =~ 'xyzabcxyzabc' )
p( /abc/ =~ 'xycab' )
p( /[abc]/ =~ 'xycba' )

