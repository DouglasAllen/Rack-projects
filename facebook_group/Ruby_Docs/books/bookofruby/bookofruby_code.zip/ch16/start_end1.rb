# The Book of Ruby - http://www.sapphiresteel.com

puts( /^a/ =~ 'abc' )
puts( /^b/ =~ 'abc' )
puts( /c$/ =~ 'abc' )
puts( /b$/ =~ 'abc' )
