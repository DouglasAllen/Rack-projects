The Book of Ruby - http://www.sapphiresteel.com

The files in this chapter are NOT 'ready-to-run'. They can only be used as
part of a Ruby On Rails application. If you have problems getting your code
to work as described in the book, check your code alongside these samples
or copy and paste the code into the appropriate files as explained in the text.