# The Book of Ruby - http://www.sapphiresteel.com

p( [1,[2,3]].flatten )
p( [1,2,nil,3].compact )
p( [1,nil,[2,nil,3]].flatten.compact )