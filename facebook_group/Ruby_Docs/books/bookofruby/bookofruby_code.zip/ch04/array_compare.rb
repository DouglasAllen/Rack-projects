# The Book of Ruby - http://www.sapphiresteel.com

arr1=[1,2,3,4,5]
arr2=[1,2,3,4,5]
arr3=[1,2,3,4]
arr4=[1,2,3,5]
arr5=[1000,2000,3000]
arr6=[1,2]
arr7=[2,1]
arr8=["hello", "world"]
arr9=["Hello", "World"]


p([1,2,3]<=>[2,3,4])
p([2,3,4]<=>[1,2,3])
p([1,2,3,4]<=>[1,2,3])
p([1,2,3,4]<=>[100,200,300])
p([1,2,3]<=>["1","2","3"])

puts( "---More examples---")
p(arr1<=>arr2)	#1
p(arr3<=>arr1)	#2
p(arr4<=>arr3)	#3
p(arr5<=>arr4)	#4
p(arr7<=>arr6)	#5
p(arr8<=>arr7)	#6
p(arr9<=>arr8)  #7